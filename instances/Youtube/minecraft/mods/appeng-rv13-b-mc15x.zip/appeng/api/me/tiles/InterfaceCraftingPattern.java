package appeng.api.me.tiles;

import java.util.List;

import net.minecraft.item.ItemStack;

public class InterfaceCraftingPattern {
	
	/**
	 * list of all the inputs.
	 */
	public List<ItemStack> Inputs;
	
	/**
	 * the output of the pattern.
	 */
	public ItemStack Output;
	
}
